function register() {
  alert("REGISTER CLIQUÉ");
  
  let user = document.getElementById("regUser").value;
  let pass = document.getElementById("regPass").value;
  
  if (user === "" || pass === "") {
    alert("Remplis tout");
    return;
  }
  
  if (localStorage.getItem("user_" + user)) {
    alert("Utilisateur déjà existant");
    return;
  }
  
  localStorage.setItem("user_" + user, pass);
  alert("Compte créé ✅");
  window.location.href = "login.html";
}
alert("script.js chargé");
let items = JSON.parse(localStorage.getItem("items")) || [];

function loadItems() {
  let box = document.getElementById("market");
  if (!box) return;
  
  box.innerHTML = "";
  
  items.forEach((item, index) => {
    box.innerHTML += `
<div class="card">
<img src="${item.image}">
<h3>${item.name}</h3>
<p>${item.desc}</p>
<b>${item.price}$</b>

<div class="actions">
<button onclick="addFav(${index})">❤️</button>
<button onclick="openChat()">💬</button>
<button onclick="deleteItem(${index})">🗑️</button>
</div>

</div>
`;
  });
}
function postItem() {
  
  let name = document.getElementById("itemName").value;
  let price = document.getElementById("itemPrice").value;
  let desc = document.getElementById("itemDesc").value;
  let imgInput = document.getElementById("itemImage");
  
  if (name == "" || price == "" || desc == "" || imgInput.files.length == 0) {
    alert("Fill all fields");
    return;
  }
  
  let reader = new FileReader();
  
  reader.onload = function() {
    items.push({
      name: name,
      price: price,
      desc: desc,
      image: reader.result
    });
    
    localStorage.setItem("items", JSON.stringify(items));
    alert("Item posted!");
  }
  
  reader.readAsDataURL(imgInput.files[0]);
}
let favs = JSON.parse(localStorage.getItem("favs")) || [];

function addFav(i) {
  favs.push(items[i]);
  localStorage.setItem("favs", JSON.stringify(favs));
  alert("Added to favorites");
}

function deleteItem(i) {
  items.splice(i, 1);
  localStorage.setItem("items", JSON.stringify(items));
  loadItems();
}

function openChat() {
  window.location.href = "chat.html";
}
let messages = JSON.parse(localStorage.getItem("messages")) || [];

function sendMessage() {
  let id = localStorage.getItem("currentChat");
  let input = document.getElementById("chatInput");
  if (input.value.trim() === "") return;
  
  let messages = JSON.parse(localStorage.getItem("chat_" + id)) || [];
  
  let user = localStorage.getItem("currentUser") || "Guest";
  
  messages.push({
    user: user,
    text: input.value
  });
  
  localStorage.setItem("chat_" + id, JSON.stringify(messages));
  input.value = "";
  loadChat();
}

function loadChat() {
  let id = localStorage.getItem("currentChat");
  let messages = JSON.parse(localStorage.getItem("chat_" + id)) || [];
  let box = document.getElementById("chatBox");
  
  box.innerHTML = "";
  
  let currentUser = localStorage.getItem("currentUser");
  
  messages.forEach(m => {
    let cls = m.user === currentUser ? "me" : "other";
    box.innerHTML += `
      <div class="msg ${cls}">
        <strong>${m.user}</strong><br>
        ${m.text}
      </div>
    `;
  });
  
  box.scrollTop = box.scrollHeight;
}
function loadProfile() {
  let user = JSON.parse(localStorage.getItem("currentUser"));
  if (!user) return;
  
  document.getElementById("username").innerText = user.username;
  document.getElementById("role").innerText = user.role || "Member";
}

function loadFavs() {
  let box = document.getElementById("favBox");
  if (!box) return;
  
  box.innerHTML = "";
  
  favs.forEach(item => {
    box.innerHTML += `
<div class="card">
<img src="${item.image}">
<h3>${item.name}</h3>
<b>${item.price}$</b>
</div>
`;
  });
}
function loadAdminPosts() {
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  let box = document.getElementById("adminPosts");
  
  box.innerHTML = "";
  
  posts.forEach((post, index) => {
    box.innerHTML += `
      <div class="admin-card">
        <h3>${post.title}</h3>
        <p>${post.price}</p>
        <button onclick="deletePost(${index})">Delete</button>
      </div>
    `;
  });
}
function isAdmin() {
  let user = JSON.parse(localStorage.getItem("currentUser"));
  return user && user.role === "admin";
}
function loadAdmin() {
  if (!isAdmin()) {
    document.body.innerHTML = "<h2>Access denied</h2>";
    return;
  }
  
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  let users = JSON.parse(localStorage.getItem("users")) || [];
  
  document.getElementById("postsCount").innerText = posts.length;
  document.getElementById("usersCount").innerText = users.length;
  
  let box = document.getElementById("adminContent");
  box.innerHTML = "";
  
  posts.forEach((p, i) => {
    box.innerHTML += `
      <div class="card">
        <h3>${p.title}</h3>
        <p>${p.price || ""}</p>
        <button class="btn" onclick="deletePost(${i})">Delete</button>
      </div>
    `;
  });
}

function deletePost(i) {
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  posts.splice(i, 1);
  localStorage.setItem("posts", JSON.stringify(posts));
  location.reload();
}
localStorage.setItem("currentUser", JSON.stringify({
  username: "admin",
  role: "admin"
}))

function protectAdmin() {
  let user = JSON.parse(localStorage.getItem("currentUser"));
  if (!user || user.role !== "admin") {
    window.location = "index.html";
  }
}
let user = JSON.parse(localStorage.getItem("currentUser"));
if (!user || user.role !== "admin") {
  let btn = document.getElementById("adminBtn");
  if (btn) btn.style.display = "none";
}
function loadCheckout() {
  let item = JSON.parse(localStorage.getItem("selectedItem"));
  if (!item) return;
  
  document.getElementById("itemName").innerText = item.title;
  document.getElementById("itemPrice").innerText = item.price + " FCFA";
}

function pay() {
  alert("Payment successful ✅ (simulation)");
  window.location = "profile.html";
}
function buyItem(i) {
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  localStorage.setItem("selectedItem", JSON.stringify(posts[i]));
  window.location = "checkout.html";
}
function loadMarket() {
  let market = document.getElementById("market");
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  
  market.innerHTML = "";
  
 posts.forEach((post, index) => {
 market.innerHTML += `
  <div class="card">
    ${post.image ? `<img src="${post.image}" class="post-img">` : ""}
    <h3>${post.title}</h3>
    <p>${post.desc}</p>
    <p><b>${post.price} FCFA</b></p>
    <button class="btn" onclick="buyPost('${post.title}')">Acheter</button>
  </div>
`;
});
}
function buyItem(index) {
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  localStorage.setItem("selectedItem", JSON.stringify(posts[index]));
  window.location = "checkout.html";
}
function createPost() {
  let title = document.getElementById("postTitle").value;
  let price = document.getElementById("postPrice").value;
  let desc = document.getElementById("postDesc").value;
  let imageInput = document.getElementById("postImage");
  
  if (!title || !price) {
    alert("Fill all fields");
    return;
  }
  
  let reader = new FileReader();
  
  reader.onload = function() {
    let posts = JSON.parse(localStorage.getItem("posts")) || [];
    
    posts.push({
      title: title,
      price: price,
      description: desc,
      image: reader.result
    });
    
    localStorage.setItem("posts", JSON.stringify(posts));
    alert("Post created ✅");
    window.location = "market.html";
  };
  
  if (imageInput.files[0]) {
    reader.readAsDataURL(imageInput.files[0]);
  } else {
    reader.onload();
  }
}
function addPost() {
  let title = document.getElementById("title").value;
  let desc = document.getElementById("desc").value;
  let price = document.getElementById("price").value;
  let imgInput = document.getElementById("image");
  
  if (title === "" || desc === "" || price === "") {
    alert("Remplis tout");
    return;
  }
  
  let reader = new FileReader();
  reader.onload = function() {
    let posts = JSON.parse(localStorage.getItem("posts")) || [];
    
    posts.push({
      title: title,
      desc: desc,
      price: price,
      image: reader.result,
      author: localStorage.getItem("currentUser")
    });
    
    localStorage.setItem("posts", JSON.stringify(posts));
    alert("Service posté ✅");
    window.location.href = "market.html";
  };
  
  if (imgInput.files[0]) {
    reader.readAsDataURL(imgInput.files[0]);
  } else {
    reader.onload();
  }
}
function buyPost(title) {
  localStorage.setItem("selectedPost", title);
  window.location.href = "profile.html";
}
function register() {
  let user = document.getElementById("regUser").value;
  let pass = document.getElementById("regPass").value;
  
  if (user === "" || pass === "") {
    alert("Remplis tout");
    return;
  }
  
  if (localStorage.getItem("user_" + user)) {
    alert("Utilisateur déjà existant");
    return;
  }
  
  localStorage.setItem("user_" + user, pass);
  localStorage.setItem("currentUser", user); // auto-login
  
  alert("Compte créé et connecté ✅");
  window.location.href = "index.html";
}
function logout() {
  localStorage.removeItem("currentUser");
  window.location.href = "login.html";
}
function loadProfile() {
  let user = localStorage.getItem("currentUser");
  if (!user) {
    window.location.href = "login.html";
    return;
  }
  
  document.getElementById("userInfo").innerText =
    "Connecté en tant que : " + user;
  
  let posts = JSON.parse(localStorage.getItem("posts")) || [];
  let myPosts = document.getElementById("myPosts");
  
  myPosts.innerHTML = "";
  
  posts.filter(p => p.author === user).forEach(post => {
    myPosts.innerHTML += `
      <div class="card">
        <h4>${post.title}</h4>
        <p>${post.price} FCFA</p>
      </div>
    `;
  });
}
function goBack() {
  window.history.back();
}